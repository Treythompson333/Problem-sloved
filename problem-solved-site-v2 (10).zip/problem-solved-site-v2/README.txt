PROBLEM SOLVED! DOG TRAINING — site files (Leash Path design)
Open index.html to view. Upload the whole folder to any host.

1. PHOTOS: 38 photo slots. See PHOTO-SHOT-LIST.md for exact file names + suggested shots. Drop JPGs into /images; slots fill automatically.
2. CONTACT FORM: open assets/site.js, set FORM_ENDPOINT to a live Formspree URL. Until then the form opens the visitor's email app addressed to info@problemsolvedtraining.com.
