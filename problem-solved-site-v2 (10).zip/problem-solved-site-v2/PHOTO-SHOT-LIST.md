# Photo shot list — Problem Solved! Dog Training

Drop JPGs into the `images/` folder using these exact file names. Each slot is shown as a white-bordered, slightly tilted print;
until a file exists the slot shows a labeled placeholder. Shoot or crop to the shape listed (width:height) for the cleanest result — any size works, it crops to fit.


## Home
- `home-hero-1.jpg` (4:5) — Dog smiling on a picnic table at the park
- `home-hero-2.jpg` (4:5) — Two dogs sitting nicely on their leashes
- `home-hero-3.jpg` (4:5) — Trainer working with a dog outdoors, on leash
- `home-puppy.jpg` (4:5) — New puppy on a first-day-home routine: crate, potty break or first lesson
- `home-problems.jpg` (4:3) — Susan working one-on-one with a dog at a client’s home
- `home-freedom.jpg` (4:5) — Dog running free on a Space Coast beach or trail
- `home-individuals.jpg` (4:3) — Two very different dogs side by side: a calm one, an energetic one
- `home-household.jpg` (1:1) — A multi-dog household together on the couch or in the yard

## About
- `about-susan.jpg` (4:5) — Susan Kelly sitting on a wooded trail surrounded by five dogs
- `about-shelter.jpg` (4:3) — Susan with a shelter dog (or a dog now in a loving home)
- `about-whole-dog.jpg` (4:5) — A dog sniffing, exploring or resting on a walk
- `about-problem-solved.jpg` (4:3) — Susan mid-lesson, coaching a client
- `about-space-coast.jpg` (1:1) — Susan and a dog at the beach or a Space Coast landmark

## Training
- `training-skills.jpg` (4:5) — Dog doing a sit-stay while its owner walks away (a clear skill moment)
- `training-puppies.jpg` (4:3) — Puppy in a lesson: focused, treat in view
- `training-problems.jpg` (4:5) — Susan and a client at the front door working through a problem behavior
- `training-calm.jpg` (4:3) — Dog settled on a mat or bed while people chat nearby
- `training-freedom.jpg` (4:5) — Dog on a long line exploring a park, or out to lunch with its family

## Pricing
- `pricing-first-lesson.jpg` (4:3) — Susan and a client’s dog in a first lesson, relaxed and unhurried
- `pricing-virtual.jpg` (4:3) — Dog watching a laptop or phone video call with its owner
- `pricing-promise.jpg` (1:1) — Happy owner and dog after a successful lesson

## Virtual Consults
- `virtual-illinois.jpg` (4:3) — Susan on a video call with a client and their dog
- `virtual-fit.jpg` (4:5) — Owner filming their dog’s behavior on a phone
- `virtual-consult.jpg` (1:1) — Dog on the couch, laptop open, owner taking notes

## Gallery
- `gallery-1.jpg` (4:5) — Dog out on a walk, relaxed on a loose leash
- `gallery-2.jpg` (4:3) — Dog resting calmly beside its person
- `gallery-3.jpg` (1:1) — Puppy in a first lesson
- `gallery-4.jpg` (3:4) — Dog enjoying a beach day
- `gallery-5.jpg` (1:1) — Dog waiting patiently at a café table
- `gallery-6.jpg` (4:5) — Dog and family at the park
- `gallery-7.jpg` (4:3) — Dog greeting a visitor politely
- `gallery-8.jpg` (3:4) — Dog on a long line exploring
- `gallery-9.jpg` (1:1) — Happy dog at home
- `gallery-10.jpg` (4:3) — Dog riding along on a Space Coast outing
- `gallery-11.jpg` (4:5) — Puppy asleep after a big lesson
- `gallery-12.jpg` (1:1) — Two dogs, one household

## Contact
- `contact-phone.jpg` (4:3) — Susan on the phone, smiling, with a dog nearby
- `contact-where.jpg` (4:3) — Space Coast scenery: a beach, pier or neighborhood walk with a dog
