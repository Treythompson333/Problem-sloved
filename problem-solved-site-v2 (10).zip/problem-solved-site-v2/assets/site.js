/* Problem Solved! Dog Training — behavior */
(function () {
  document.documentElement.classList.add('js');

  /* mobile menu */
  var btn = document.querySelector('.menu-btn'), nav = document.getElementById('site-nav');
  if (btn && nav) {
    btn.addEventListener('click', function () { var o = nav.classList.toggle('open'); btn.setAttribute('aria-expanded', o ? 'true' : 'false'); });
    nav.addEventListener('click', function (e) { if (e.target.tagName === 'A') { nav.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); } });
  }

  /* reveal on scroll */
  var items = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });
    items.forEach(function (el) { io.observe(el); });
  } else items.forEach(function (el) { el.classList.add('in'); });

  /* photo slots: show a tidy placeholder until the image file exists */
  document.querySelectorAll('[data-photo] img').forEach(function (img) {
    function miss() { img.closest('[data-photo]').classList.add('empty'); img.style.display = 'none'; }
    if (img.complete && img.naturalWidth === 0) miss();
    img.addEventListener('error', miss);
  });

  /* ---------- the leash trail ---------- */
  var box = document.querySelector('.path');
  if (box) {
    var NS = 'http://www.w3.org/2000/svg';
    var svg = box.querySelector('.trail');
    var line = document.createElementNS(NS, 'path'); line.setAttribute('class', 'line'); svg.appendChild(line);
    var pup = document.createElementNS(NS, 'g'); pup.setAttribute('class', 'pup');
    pup.innerHTML = '<circle r="21"/><g transform="translate(-13 -13) scale(.41)"><ellipse cx="20" cy="22" rx="5" ry="7" fill="#F2F0EC"/><ellipse cx="44" cy="22" rx="5" ry="7" fill="#F2F0EC"/><ellipse cx="10" cy="36" rx="5" ry="7" fill="#F2F0EC"/><ellipse cx="54" cy="36" rx="5" ry="7" fill="#F2F0EC"/><path d="M32 30c-9 0-17 10-17 17 0 6 5 8 10 7 3-.6 5-1.6 7-1.6s4 1 7 1.6c5 1 10-1 10-7 0-7-8-17-17-17z" fill="#F2F0EC"/></g>';
    svg.appendChild(pup);
    var total = 0;

    function pts() {
      var br = box.getBoundingClientRect(), out = [];
      box.querySelectorAll('.pstart,.node,.pend').forEach(function (el) {
        var r = el.getBoundingClientRect();
        out.push({ x: r.left + r.width / 2 - br.left, y: r.top + r.height / 2 - br.top });
      });
      return out;
    }
    function build() {
      var W = box.offsetWidth, H = box.offsetHeight, P = pts();
      if (P.length < 2) return;
      svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
      var mobile = W < 900, amp = mobile ? 14 : Math.min(W * 0.2, 260), all = [P[0]];
      for (var i = 0; i < P.length - 1; i++) {
        var a = P[i], b = P[i + 1], dir = (i % 2 ? -1 : 1);
        all.push({ x: (a.x + b.x) / 2 + dir * amp, y: (a.y + b.y) / 2 });
        all.push(b);
      }
      var d = 'M' + all[0].x + ' ' + all[0].y;
      for (var j = 0; j < all.length - 1; j++) {
        var p0 = all[Math.max(0, j - 1)], p1 = all[j], p2 = all[j + 1], p3 = all[Math.min(all.length - 1, j + 2)], t = 6;
        d += ' C' + (p1.x + (p2.x - p0.x) / t) + ' ' + (p1.y + (p2.y - p0.y) / t) + ',' + (p2.x - (p3.x - p1.x) / t) + ' ' + (p2.y - (p3.y - p1.y) / t) + ',' + p2.x + ' ' + p2.y;
      }
      line.setAttribute('d', d);
      total = line.getTotalLength();
      move();
    }
    function move() {
      if (!total) return;
      var r = box.getBoundingClientRect(), vh = window.innerHeight;
      var prog = Math.min(1, Math.max(0, (vh * 0.55 - r.top) / r.height));
      var pt = line.getPointAtLength(prog * total);
      pup.setAttribute('transform', 'translate(' + pt.x + ' ' + pt.y + ')');
    }
    var raf;
    window.addEventListener('scroll', function () { cancelAnimationFrame(raf); raf = requestAnimationFrame(move); }, { passive: true });
    window.addEventListener('resize', function () { cancelAnimationFrame(raf); raf = requestAnimationFrame(build); });
    window.addEventListener('load', build);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(build);
    setTimeout(build, 300); setTimeout(build, 1200);
    if ('ResizeObserver' in window) new ResizeObserver(function () { cancelAnimationFrame(raf); raf = requestAnimationFrame(build); }).observe(box);
    document.addEventListener('toggle', function () { setTimeout(build, 30); }, true);
    build();
  }

  /* gallery lightbox */
  var lb = document.querySelector('.lightbox');
  if (lb) {
    var lbImg = lb.querySelector('img');
    document.querySelectorAll('.masonry .ph').forEach(function (s) {
      s.addEventListener('click', function () {
        if (s.classList.contains('empty')) return;
        var im = s.querySelector('img'); lbImg.src = im.src; lbImg.alt = im.alt; lb.classList.add('open');
      });
    });
    lb.addEventListener('click', function () { lb.classList.remove('open'); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') lb.classList.remove('open'); });
  }

  /* contact form — set FORM_ENDPOINT to a live Formspree URL (https://formspree.io/f/xxxx).
     Until then it opens the visitor's email app, pre-filled to info@problemsolvedtraining.com. */
  var FORM_ENDPOINT = '', PHONE = '708-250-7693';
  var form = document.getElementById('lead-form');
  if (form) {
    var msg = form.querySelector('.form-msg');
    var show = function (k, h) { msg.className = 'form-msg ' + k; msg.innerHTML = h; msg.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); };
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (form.querySelector('.hp input').value) return;
      var data = new FormData(form), submit = form.querySelector('button[type=submit]');
      var ok = 'Thank you. Your message is in. I’ll be in touch soon. If it’s easier, you can always call or text me at <a class="inline-link" href="tel:+17082507693">' + PHONE + '</a>.';
      var err = 'Something went wrong and your message didn’t go through. Please call or text me at <a class="inline-link" href="tel:+17082507693">' + PHONE + '</a> and we’ll get started that way.';
      if (!FORM_ENDPOINT) {
        var body = ['Name: ' + data.get('name'), 'Phone: ' + data.get('phone'), 'Email: ' + data.get('email'), 'City: ' + data.get('city'), 'Dog’s name: ' + data.get('dog_name'), 'Dog’s age/breed: ' + data.get('dog_info'), '', 'What would you like help with:', data.get('help')].join('\n');
        window.location.href = 'mailto:info@problemsolvedtraining.com?subject=' + encodeURIComponent('New lesson inquiry from ' + data.get('name')) + '&body=' + encodeURIComponent(body);
        show('ok', ok); return;
      }
      submit.disabled = true;
      fetch(FORM_ENDPOINT, { method: 'POST', body: data, headers: { Accept: 'application/json' } })
        .then(function (r) { if (!r.ok) throw 0; form.reset(); show('ok', ok); })
        .catch(function () { show('err', err); })
        .then(function () { submit.disabled = false; });
    });
  }
})();
